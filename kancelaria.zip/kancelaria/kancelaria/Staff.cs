﻿using System.Data.SqlClient;
using System.Windows.Forms;
using ImdLib7;

namespace kancelaria
{
    public partial class Staff : Form
    {
        public Staff()
        {
            InitializeComponent();
        }
        public Staff(DataGridViewSelectedCellCollection Cells):this()
        {
            boxID.Text = Cells[0].Value+"";
            boxFIO.Text = Cells[1].Value + "";
            boxJOB.Text = Cells[2].Value + "";
            boxDate.Text = Cells[3].Value + "";
            boxNumberPhone.Text = Cells[4].Value + "";
            boxAdress.Text = Cells[5].Value + "";
        }

        private void btnSave_Click(object sender, System.EventArgs e)
        {
            if (string.IsNullOrEmpty(boxID.Text))
            {
                try
                {
                new SqlCommand($"insert into Сотрудники values('{boxFIO.Text}','{boxJOB.Text}','{boxDate.Text}','{boxNumberPhone.Text}','{boxAdress.Text}')", Connection.getConnection()).ExecuteNonQuery();
                MessageBox.Show("Запись добавлена");
                DialogResult = DialogResult.OK;
                }
                catch
                {
                    MessageBox.Show("Заполните поля корректно");
                }
                
            }
            else
            {
                try
                {
                    new SqlCommand($"update Сотрудники set ФИО='{boxFIO.Text}',Должность='{boxJOB.Text}',ГодРождения='{boxDate.Text}',НомерТелефона='{boxNumberPhone.Text}',Адрес='{boxAdress.Text}' where Код_сотрудника='{boxID.Text}'", Connection.getConnection()).ExecuteNonQuery();
                    MessageBox.Show("Запись изменена");
                    DialogResult = DialogResult.OK;
                }
                catch (System.Exception)
            {
                MessageBox.Show("Заполните поля корректно");
            }

        }
        }
    }
}
