﻿using System.Data.SqlClient;
using System.Windows.Forms;
using ImdLib7;

namespace kancelaria
{
    public partial class MainForm : Form
    {
        private int ExtsForm = 1;
        public MainForm()
        {
            InitializeComponent();
            label1.Text = "Логин: " + UserAuth.login;
            MainDataGridView.FillDataGridFromQuery("*", "Сотрудники");
        }


        private void btnStaff_Click(object sender, System.EventArgs e)
        {
            MainDataGridView.FillDataGridFromQuery("*", "Сотрудники");
            ExtsForm = 1;
        }

        private void btnSklad_Click(object sender, System.EventArgs e)
        {
            MainDataGridView.FillDataGridFromQuery("*", "Склад");
            ExtsForm = 2;
        }

        private void btnTovars_Click(object sender, System.EventArgs e)
        {
            MainDataGridView.FillDataGridFromQuery("*", "Товар");
            ExtsForm = 3;
        }

        private void btnSupp_Click(object sender, System.EventArgs e)
        {
            MainDataGridView.FillDataGridFromQuery("*", "Поставщик");
            ExtsForm = 4;

        }

        private void btnAdd_Click(object sender, System.EventArgs e)
        {
            switch (ExtsForm)
            {
                case 1:
                    if (new Staff().ShowDialog() == DialogResult.OK)
                    {
                        MainDataGridView.FillDataGridFromQuery("*", "Сотрудники");
                    }
                    break;
                case 2:
                    if (new Sklad().ShowDialog() == DialogResult.OK)
                    {
                        MainDataGridView.FillDataGridFromQuery("*", "Склад");
                    }
                    break;
                case 3:
                    if (new Tovars().ShowDialog() == DialogResult.OK)
                    {
                        MainDataGridView.FillDataGridFromQuery("*", "Товар");
                    }
                    break;
                case 4:
                    if (new Supplier().ShowDialog() == DialogResult.OK)
                    {
                        MainDataGridView.FillDataGridFromQuery("*", "Поставщик");
                    }
                    break;
            }
        }

        private void btnEdit_Click(object sender, System.EventArgs e)
        {
            if (MainDataGridView.SelectedCells.Count != 0)
            {
                switch (ExtsForm)
                {
                    case 1:
                        if (new Staff(MainDataGridView.SelectedCells).ShowDialog() == DialogResult.OK)
                        {
                            MainDataGridView.FillDataGridFromQuery("*", "Сотрудники");
                        }
                        break;
                    case 2:
                        if (new Sklad(MainDataGridView.SelectedCells).ShowDialog() == DialogResult.OK)
                        {
                            MainDataGridView.FillDataGridFromQuery("*", "Склад");
                        }
                        break;
                    case 3:
                        if (new Tovars(MainDataGridView.SelectedCells).ShowDialog() == DialogResult.OK)
                        {
                            MainDataGridView.FillDataGridFromQuery("*", "Товар");
                        }
                        break;
                    case 4:
                        if (new Supplier(MainDataGridView.SelectedCells).ShowDialog() == DialogResult.OK)
                        {
                            MainDataGridView.FillDataGridFromQuery("*", "Поставщик");
                        }
                        break;
                }
            }
            else
            {
                MessageBox.Show("Выберите строку");
            }
        }

        private void MainForm_Load(object sender, System.EventArgs e) => MainDataGridView.ClearSelection();

        private void btnRemove_Click(object sender, System.EventArgs e)
        {
            if (MainDataGridView.SelectedCells.Count != 0)
            {
                switch (ExtsForm)
                {
                    case 1:
                        new SqlCommand($"delete from Сотрудники where [Код_сотрудника]='{(int)MainDataGridView.SelectedCells[0].Value}'", Connection.getConnection()).ExecuteNonQuery();
                        MessageBox.Show("Строка удалена");
                        MainDataGridView.FillDataGridFromQuery("*", "Сотрудники");
                        break;
                    case 2:
                        new SqlCommand($"delete from Склад where [Код_склада]='{(int)MainDataGridView.SelectedCells[0].Value}'", Connection.getConnection()).ExecuteNonQuery();
                        MessageBox.Show("Строка удалена");
                        MainDataGridView.FillDataGridFromQuery("*", "Склад");
                        break;
                    case 3:
                        new SqlCommand($"delete from Товар where [Код_товара]='{(int)MainDataGridView.SelectedCells[0].Value}'", Connection.getConnection()).ExecuteNonQuery();
                        MessageBox.Show("Строка удалена");
                        MainDataGridView.FillDataGridFromQuery("*", "Товар");
                        break;
                    case 4:
                        new SqlCommand($"delete from Поставщик where [Код_Поставщика]='{(int)MainDataGridView.SelectedCells[0].Value}'", Connection.getConnection()).ExecuteNonQuery();
                        MessageBox.Show("Строка удалена");
                        MainDataGridView.FillDataGridFromQuery("*", "Поставщик");
                        break;
                }
            }
            else
            {
                MessageBox.Show("Выберите строку для удаления");
            }
        }
    }
}
