﻿using System.Data.SqlClient;
using System.Windows.Forms;
using ImdLib7;

namespace kancelaria
{
    public partial class Sklad : Form
    {
        public Sklad() => InitializeComponent();
        public Sklad(DataGridViewSelectedCellCollection Cells) :this()
        {
            boxID.Text = Cells[0].Value + "";
            boxStellaj.Text = Cells[1].Value + "";
            boxRyad.Text = Cells[2].Value + "";
            boxCount.Text = Cells[3].Value + "";
            boxIDSupp.Text = Cells[4].Value + "";
            boxIDStaff.Text = Cells[5].Value + "";
        }

        private void btnSave_Click(object sender, System.EventArgs e)
        {
            if (string.IsNullOrEmpty(boxID.Text))
            {
                try
                {
                new SqlCommand($"insert into Склад values('{boxStellaj.Text}','{boxRyad.Text}','{boxCount.Text}','{boxIDSupp.Text}','{boxIDStaff.Text}')",Connection.getConnection()).ExecuteNonQuery();
                MessageBox.Show("Запись добавлена");
                DialogResult = DialogResult.OK;
                }
                catch (System.Exception)
                {
                    MessageBox.Show("Заполните поля корректно");
                }
                
            }
            else
            {
                try
                {
                    new SqlCommand($"update Таблица set Стеллаж='{boxStellaj.Text}',Ряд='{boxRyad.Text}',КоличествоТовара='{boxCount.Text}',Код_поставщика='{boxIDSupp.Text}', Код_Сотрудника='{boxIDStaff.Text}' where Код_склада='{boxID.Text}'", Connection.getConnection()).ExecuteNonQuery();
                    MessageBox.Show("Запись изменена");
                }
                catch
                {
                    MessageBox.Show("Заполните поля корректно");
                }
                
            }
        }
    }
}
