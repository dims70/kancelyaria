﻿using ImdLib7;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace kancelaria
{
    public partial class Tovars : Form
    {
        public Tovars()
        {
            InitializeComponent();
        }
        public Tovars(DataGridViewSelectedCellCollection Cells) : this()
        {
            boxID.Text = Cells[0].Value+"";
            boxName.Text = Cells[1].Value + "";
            boxSKODE.Text = Cells[2].Value + "";
            boxCost.Text = Cells[3].Value + "";
            boxIDSklad.Text = Cells[4].Value + "";
            boxBuilder.Text = Cells[5].Value + "";
        }

        private void btnSave_Click(object sender, System.EventArgs e)
        {
            if (string.IsNullOrEmpty(boxID.Text))
            {
                try
                { 
                new SqlCommand($"insert into Товар values('{boxName.Text}','{boxSKODE.Text}','{boxCost.Text}','{boxIDSklad.Text}','{boxBuilder.Text}')",Connection.getConnection()).ExecuteNonQuery();
                    MessageBox.Show("Запись добавлена");
                    DialogResult = DialogResult.OK;
                }
                catch
                {
                    MessageBox.Show("Заполните поля корректно");
                }
            }
            else
            {   try
                {
                new SqlCommand($"update Товар set Наименование='{boxName.Text}',Штрихкод='{boxSKODE.Text}',Цена='{boxCost.Text}',Код_склада='{boxIDSklad.Text}',Производитель='{boxBuilder.Text}' where Код_товара = '{boxID.Text}'", Connection.getConnection()).ExecuteNonQuery();
                MessageBox.Show("Запись изменена");
                DialogResult = DialogResult.OK;
                }
                catch
                {
                    MessageBox.Show("Заполните поля корректно");
                }
            }
        }
    }
}
