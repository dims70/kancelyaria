﻿using ImdLib7;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace kancelaria
{
    public partial class Supplier : Form
    {
        public Supplier()
        {
            InitializeComponent();
        }
        public Supplier(DataGridViewSelectedCellCollection Cells) : this()
        {
            boxID.Text = Cells[0].Value+"";
            boxName.Text = Cells[1].Value + "";
            boxAdress.Text = Cells[2].Value + "";
            boxNumberPhone.Text = Cells[3].Value + "";
            boxEmail.Text = Cells[4].Value + "";
        }

        private void btnSave_Click(object sender, System.EventArgs e)
        {
            if (string.IsNullOrEmpty(boxID.Text))
            {
                try
                {
                  new SqlCommand($"insert into Поставщик values('{boxName.Text}','{boxAdress.Text}','{boxNumberPhone.Text}','{boxEmail.Text}')", Connection.getConnection()).ExecuteNonQuery();
                  MessageBox.Show("Запись создана");
                    DialogResult = DialogResult.OK;
                }
                catch
                {
                    MessageBox.Show("Заполните поля корректно");
                }
                
            }
            else
            {
                try
                {
                new SqlCommand($"update Поставщик set НазваниеПоставщика='{boxName.Text}',ЮридическийАдрес='{boxAdress.Text}',Телефон='{boxNumberPhone.Text}',e_mail='{boxID.Text}' where Код_Поставщика ='{boxID.Text}'", Connection.getConnection()).ExecuteNonQuery();
                MessageBox.Show("Запись изменена");
                DialogResult = DialogResult.OK;
                }
                catch 
                {
                    MessageBox.Show("Заполните поля корректно");
                }
                
            }
        }
    }
}
