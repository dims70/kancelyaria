﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace kancelaria
{
    public static class UserAuth
    {
        public static int idUser { get; set; }
        public static string  login { get; set; }
    }
}
