﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using ImdLib7;
namespace kancelaria
{
    public partial class AuthForm : Form
    {
        public AuthForm()
        {
            InitializeComponent();
            Connection.StringConnection = @"Data Source = DIMA\SQLEXPRESS; Initial Catalog = 'магазин канцелярия';Integrated Security = true";
            Connection.getConnection().Open();
        }

        private void btnAuth_Click(object sender, EventArgs e)
        {
            var cmd = new SqlCommand($"select * from [Логины и пароли] where Логин = '{boxLogin.Text}' and Пароль = '{boxPass.Text}'",Connection.getConnection());
            if (cmd.ExecuteScalar() != null)
            {
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    UserAuth.idUser = (int)reader[0];
                    UserAuth.login = (string)reader[1];
                }
                reader.Close();
                new MainForm().Show();
            }
            else
            {
                MessageBox.Show("Логин и/или пароль неверны");
            }
        }
    }
}
