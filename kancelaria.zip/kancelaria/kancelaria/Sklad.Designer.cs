﻿namespace kancelaria
{
    partial class Sklad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSave = new System.Windows.Forms.Button();
            this.boxIDStaff = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.boxIDSupp = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.boxCount = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.boxRyad = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.boxStellaj = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.boxID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(246, 329);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(253, 37);
            this.btnSave.TabIndex = 38;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // boxIDStaff
            // 
            this.boxIDStaff.Location = new System.Drawing.Point(345, 281);
            this.boxIDStaff.Name = "boxIDStaff";
            this.boxIDStaff.Size = new System.Drawing.Size(154, 20);
            this.boxIDStaff.TabIndex = 37;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(250, 284);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 13);
            this.label6.TabIndex = 36;
            this.label6.Text = "Код сотрудника:";
            // 
            // boxIDSupp
            // 
            this.boxIDSupp.Location = new System.Drawing.Point(345, 243);
            this.boxIDSupp.Name = "boxIDSupp";
            this.boxIDSupp.Size = new System.Drawing.Size(154, 20);
            this.boxIDSupp.TabIndex = 35;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(246, 246);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 13);
            this.label5.TabIndex = 34;
            this.label5.Text = "Код поставщика:";
            // 
            // boxCount
            // 
            this.boxCount.Location = new System.Drawing.Point(345, 207);
            this.boxCount.Name = "boxCount";
            this.boxCount.Size = new System.Drawing.Size(154, 20);
            this.boxCount.TabIndex = 33;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(257, 210);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 13);
            this.label4.TabIndex = 32;
            this.label4.Text = "Кол-во товара:";
            // 
            // boxRyad
            // 
            this.boxRyad.Location = new System.Drawing.Point(345, 167);
            this.boxRyad.Name = "boxRyad";
            this.boxRyad.Size = new System.Drawing.Size(154, 20);
            this.boxRyad.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(305, 170);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 30;
            this.label3.Text = "Ряд:";
            // 
            // boxStellaj
            // 
            this.boxStellaj.Location = new System.Drawing.Point(345, 127);
            this.boxStellaj.Name = "boxStellaj";
            this.boxStellaj.Size = new System.Drawing.Size(154, 20);
            this.boxStellaj.TabIndex = 29;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(281, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 28;
            this.label2.Text = "Стеллаж:";
            // 
            // boxID
            // 
            this.boxID.Location = new System.Drawing.Point(345, 92);
            this.boxID.Name = "boxID";
            this.boxID.ReadOnly = true;
            this.boxID.Size = new System.Drawing.Size(154, 20);
            this.boxID.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(272, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "Код склада:";
            // 
            // Sklad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.boxIDStaff);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.boxIDSupp);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.boxCount);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.boxRyad);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.boxStellaj);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.boxID);
            this.Controls.Add(this.label1);
            this.Name = "Sklad";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sklad";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox boxIDStaff;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox boxIDSupp;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox boxCount;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox boxRyad;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox boxStellaj;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox boxID;
        private System.Windows.Forms.Label label1;
    }
}